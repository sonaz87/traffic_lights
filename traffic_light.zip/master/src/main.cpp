#include <Arduino.h>
#include <SoftwareSerial.h>
#define BUFLEN 20
typedef enum
{
  RED,
  GREEN
} Color;

int greenLightPin = 8;
int redLightPin = 9;

//
// Watch it!!
// In the lines below you can configure if you would like to use
// serial communication of additional hardware pins or via regular serial pins:
//
SoftwareSerial mySerial(10, 11);
// #define mySerial Serial

#define MESSAGE_START ('#')
#define MESSAGE_STOP (';')
const unsigned long MAX_TIME_SINCE_LAST_MESSAGE = 2500;
const unsigned long GREEN_DURATION = 2000;
const unsigned long RED_DELAY_DURATION = 1000;
const unsigned long REPLY_TIMEOUT = 500;
unsigned long int stateStartTime = 0;
uint8_t currentState;

typedef enum
{
  WAITING_FOR_MESSAGE,
  READING_MESSAGE
} CommunicationState;
typedef enum
{
  CONNECTING,
  MASTER_GREEN,
  BOTH_RED_AFTER_MASTER_GREEN,
  BOTH_RED_AFTER_SLAVE_GREEN,
  SLAVE_GREEN
} ControlState;

typedef enum
{
  NONE,
  CONNECTION_OK,
  CONNECTION_NOK,
  TIMER_EXPIRED,
  TIMER_BOTH_RED_EXPIRED
} Event;

CommunicationState comState = WAITING_FOR_MESSAGE;
char incomingMessageBuffer[BUFLEN];
uint8_t bufferIndex = 0;

int readIncomingMessage(char *buf)
{
  buf[0] = '\0'; // clear output buffer
  int retval = 0;

  while (mySerial.available() > 0)
  {
    char incomingByte = mySerial.read();

    // Serial.print(incomingByte); // optional debug

    if (comState == WAITING_FOR_MESSAGE)
    {
      if (incomingByte == MESSAGE_START)
      {
        comState = READING_MESSAGE;
        bufferIndex = 0;
      }
    }
    else if (comState == READING_MESSAGE)
    {
      if (incomingByte == MESSAGE_STOP)
      {
        incomingMessageBuffer[bufferIndex] = '\0';   // terminate string
        strncpy(buf, incomingMessageBuffer, BUFLEN); // copy to output
        comState = WAITING_FOR_MESSAGE;
        retval = 1;
        break;
      }
      else
      {
        if (bufferIndex < BUFLEN - 1)
        {
          incomingMessageBuffer[bufferIndex++] = incomingByte;
        }
        else
        {
          // overflow safety
          incomingMessageBuffer[BUFLEN - 1] = '\0';
          comState = WAITING_FOR_MESSAGE;
          retval = -1;
          break;
        }
      }
    }
  }

  return retval;
}

void sendMessage(const char *mes)
{
  mySerial.write(MESSAGE_START); // write is faster than print for chars
  mySerial.write(mes);
  Serial.print("sendMessage mes: ");
  Serial.println(mes);
  mySerial.write(MESSAGE_STOP);
}

bool checkReply(char *buffer)
{
  unsigned long replyStart = millis();
  while (millis() - replyStart < REPLY_TIMEOUT)
  {
    if (readIncomingMessage(buffer) == 1)
    {
      return strcmp(buffer, "ACK") == 0;
    }
  }
  return false;
}

void setColor(Color color)
{
  if (color == RED)
  {
    digitalWrite(redLightPin, HIGH);
    digitalWrite(greenLightPin, LOW);
  }
  else
  {
    digitalWrite(greenLightPin, HIGH);
    digitalWrite(redLightPin, LOW);
  }
}

void setup()
{
  Serial.begin(9600);
  mySerial.begin(9600);
  Serial.println("Master started");

  int pins[2] = {redLightPin, greenLightPin};
  // instead of using PinMode(), setting up the pins through the registers
  DDRB |= (1 << DDB0) | (1 << DDB1);
  PORTB &= ~((1 << PORTB0) | (1 << PORTB1));
  setColor(RED);
  currentState = CONNECTING;
}

void loop()
{
  char buffer[BUFLEN];
  switch (currentState)
  {

  case CONNECTING:
    Serial.println("state: CONNECTING");
    {
      sendMessage("BEAT");
      stateStartTime = millis();
      bool gotReply = false;

      while (millis() - stateStartTime < REPLY_TIMEOUT)
      {
        if (readIncomingMessage(buffer) == 1)
        {
          if (strcmp(buffer, "ACK") == 0)
          {
            gotReply = true;
          }
          break;
        }
      }

      if (gotReply)
      {
        Serial.println("Connected to slave.");
        sendMessage("RED"); // Slave to RED, just for safety
        setColor(GREEN);
        stateStartTime = millis();
        currentState = MASTER_GREEN;
      }
      else
      {
        Serial.println("No response from slave.");
        setColor(RED);
        delay(500);
      }
      break;
    }

  case MASTER_GREEN:
    Serial.println("state: MASTER GREEN");
    {
      if (millis() - stateStartTime >= GREEN_DURATION)
      {
        setColor(RED);
        stateStartTime = millis();
        currentState = BOTH_RED_AFTER_MASTER_GREEN;
      }
      break;
    }

  case BOTH_RED_AFTER_MASTER_GREEN:
    Serial.println("state: BOTH_RED_AFTER_MASTER_GREEN");
    {
      if (millis() - stateStartTime >= RED_DELAY_DURATION)
      {
        sendMessage("GREEN"); // Slave to GREEN
        if (!checkReply(buffer))
        {
          Serial.println("No ACK after GREEN, reconnecting");
          setColor(RED);
          currentState = CONNECTING;
          break;
        }
        stateStartTime = millis();
        currentState = SLAVE_GREEN;
      }
      break;
    }

  case SLAVE_GREEN:
    Serial.println("state: SLAVE_GREEN");
    {
      if (millis() - stateStartTime >= GREEN_DURATION)
      {
        sendMessage("RED"); // Slave to RED
        if (!checkReply(buffer))
        {
          Serial.println("No ACK after RED, reconnecting");
          setColor(RED);
          currentState = CONNECTING;
          break;
        }
        stateStartTime = millis();
        currentState = BOTH_RED_AFTER_SLAVE_GREEN;
      }
      break;
    }

  case BOTH_RED_AFTER_SLAVE_GREEN:
    Serial.println("state: BOTH_RED_AFTER_SLAVE_GREEN");
    {
      if (millis() - stateStartTime >= RED_DELAY_DURATION)
      {
        setColor(GREEN); // Master to GREEN
        stateStartTime = millis();
        currentState = MASTER_GREEN;
      }
      break;
    }
  }
}